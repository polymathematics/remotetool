import timer from ".js/timer.js";

new timer(
  document.querySelector(".timer")
);